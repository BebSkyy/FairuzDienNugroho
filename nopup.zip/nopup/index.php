<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id" class="translated-ltr">

<head>
    <meta charset"UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>NopUp TopUp murah terpercaya</title>

    <link rel="icon" href="logo2.png" type="image/x-icon">
    <meta name="description" content="Top Up Murah & Terpercaya Pakai NopUp">
    <meta name="keywords" content="NopUp TopUp">
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <!-- Link Swiper's CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
</head>

<body>
    <header>
        <nav class="navbar">
            <div class="container nav-wrapper">
                <a href="index.php" class="logo">
                    <img src="logo.png">
                </a>
                <div class="menu-wrapper">
                    <ul class="menu">
                        <li class="menu-item"><a href="index.php" class="menu-link active">Home</a></li>
                        <li class="menu-item"><a href="cek-pesanan.php" class="menu-link">Cek Pesanan</a></li>
                        <li class="menu-item"><a href="Syarat&ketentuan.php" class="menu-link">Syarat & ketentuan</a>
                        </li>
                    </ul>
                    <?php
                    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
                        ?>
                        <img src="user.png" class="user-pic" onclick="tonggleMenu()">
                        <div class="sub-menu-wrap" id="subMenu">
                            <div class="sub-menu">
                                <div class="user-info">
                                    <img src="user.png" />
                                    <h3><?php
                                    echo $_SESSION['user'];
                                    ?></h3>
                                </div>
                                <hr>
                                <a href="logout.php" class="sub-menu-link">
                                    <img src="logout.png">
                                    <p>Logout</p>
                                    <span>></span>
                                </a>
                            </div>
                        </div>
                        <?php
                    } else {
                        ?>
                        <a href="SignIn.php" class="btn-member">Login</a>
                    </div>
                    <?php
                    }
                    ?>
                    <div class="menu-toggle bx bxs-grid-alt">
                </div>
            </div>
        </nav>
        <div class="container1">
            <div class="content-slide">
                <div class="imgslide fade">
                    <a href="game14.php">
                    <div class="numberslide">1/4</div>
                    <img src="image 11.png" alt="">
                    </a>
                </div>
                <div class="imgslide fade">
                    <a href="index.php">
                    <div class="numberslide">2/4</div>
                    <img src="image 12.png" alt="">
                    </a>
                </div>
                <div class="imgslide fade">
                    <a href="https://www.midasbuy.com/midasbuy/id/buy/pubgm">
                    <div class="numberslide">3/4</div>
                    <img src="image 13.png" alt="">
                    </a>
                </div>
                <div class="imgslide fade">
                    <div class="numberslide">4/4</div>
                    <img src="image 14.png" alt="">
                </div>
            </div>
            <div class="page">
                <span class="dot" onClick="dotslide(1)"></span>
                <span class="dot" onClick="dotslide(2)"></span>
                <span class="dot" onClick="dotslide(3)"></span>
                <span class="dot" onClick="dotslide(4)"></span>
            </div>

        </div>
        <section class="home" id="home">
            <div class="container home-wrapper">
                <h1 class="heading">TopUp murah pakai NopUp</h1>
                <hr size="10px" width="12%" color="#1f4590" class="hr">
            </div>
        </section>
    </header>
    <section class="produk">
        <div class="container produk-wrapper">
            <div class="row1">
                <div class="title-produk">
                    <h1 class="heading-produk">Trending</h1>
                </div>
                <div class="toggle-slider">
                    <i class='bx bxs-chevron-left-circle'></i>
                    <i class='bx bxs-chevron-right-circle'></i>
                </div>
            </div>
            <div class="row2">
                <!-- Swiper -->
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide card-produk">
                            <img src="1.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game11.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Mobile Legends Bang-Bang</h1>
                                </div>
                                <div class="body-card">
                                    <p>Top up MLBB/Mobile Legends: Bang Bang sekarang semakin mudah bersama NopUp! Kamu
                                        bisa menggunakannya untuk memiliki Starlight Member, Twilight Pass, membeli skin
                                        favorit kesukaanmu. Cukup masukkan ID, pilih nominal dan lakukan pembayaran.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="2.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="https://www.midasbuy.com/midasbuy/id/homepage/pubgm">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>PUBG Mobile (Indonesia)</h1>
                                </div>
                                <div class="body-card">
                                    <p>Top up PUBG Mobile menggunakan voucher kode redeem (redeem code) hanya dalam
                                        hitungan detik! Cukup pilih jumlah voucher UC yang Anda inginkan, selesaikan
                                        pembayaran, dan kode voucher PUBG Mobile langsung terkirim dalam hitungan detik.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="3.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game14.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Call of Duty (Mobile)</h1>
                                </div>
                                <div class="body-card">
                                    <p>Top up atau beli Call of Duty Mobile Points (CP) termurah dan tercepat! Caranya
                                        mudah! Cukup isi ID, pilih nominal yang diinginkan, lakukan pembayaran, lalu CP
                                        akan langsung bertambah ke akun Call of duty Mobile kamu! Top up cod mobile bisa
                                        bayar melalui GO-PAY, DANA, OVO, BNI, BCA, CIMB Clicks, Mandiri, Permata,
                                        Indomaret, Alfamart, Kartu Kredit.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="4.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game12.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Free Fire</h1>
                                </div>
                                <div class="body-card">
                                    <p>Top up diamond Free Fire melalui NopUp. Bagaimana caranya? Kamu tinggal masukkan
                                        ID kamu lalu pilih nominal yang diinginkan. NopUp menyediakan pilihan mulai 5
                                        sampai 73.200 Free Fire Diamonds. Kamu bisa menggunakannya untuk membeli
                                        karakter, skin hingga mendapatkan item eksklusif untuk mendukung permainanmu.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="5.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game2.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Genshin Impact</h1>
                                </div>
                                <div class="body-card">
                                    <p>Top up Genshin Impact? Beli Genesis Crystals Genshin Impact dengan mudah dan
                                        cepat di NopUp! Caranya mudah! Cukup masukan UID dan Server, pilih jumlah
                                        Genesis Crystals yang diinginkan, lakukan pembayaran. Bisa bayar melalui DANA,
                                        OVO, ShopeePay, GO-PAY, LinkAja, BNI, BCA, CIMB Clicks, Mandiri, Permata,
                                        Indomaret, Alfamart, dan lain-lain.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="6.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game1.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Stumble Guys</h1>
                                </div>
                                <div class="body-card">
                                    <p>Top up Gems Stumble Guys hanya dalam hitungan detik! Cukup masukan User ID
                                        Stumble Guys Anda, pilih jumlah Gems yang Anda inginkan, selesaikan pembayaran,
                                        dan Gems akan secara langsung ditambahkan ke akun Stumble Guys Anda. Bayarlah
                                        menggunakan Bank Transfer, Alfamart, Indomaret, GoPay, OVO, Shopee Pay, DANA,
                                        dan kartu kredit.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="7.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game4.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Valorant</h1>
                                </div>
                                <div class="body-card">
                                    <p>NopUp bekerja sama dengan Riot Games untuk menawarkan top up VALORANT Points yang
                                        mudah, aman, dan nyaman. Beli VALORANT Points hanya dalam hitungan detik! Cukup
                                        masukkan riot ID, pilih jumlah VALORANT Points yang Kamu inginkan, selesaikan
                                        pembayaran, dan VALORANT Points tersebut akan langsung masuk ke akun VALORANT
                                        Kamu.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="8.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="#">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Arena of Valor</h1>
                                </div>
                                <div class="body-card">
                                    <p>Arena of Valor adalah game mobile dengan genre MOBA. Kalian sedang cari cara top
                                        up AOV praktis dan cepat? Beli voucher AOV di NopUp jawabannya. Bayarlah
                                        menggunakan Indosat, XL, Tri Indonesia, Smartfren, Bank Transfer, Alfamart,
                                        DOKU, Indomaret, GoPay, Kredivo, OVO, Shopee Pay, LinkAja, DANA, QRIS, dan kartu
                                        kredit. Tanpa perlu registrasi ataupun log-in.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="9.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game5.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Point Blank (Zepetto)</h1>
                                </div>
                                <div class="body-card">
                                    <p>Bermain Point Blank akan semakin mudah dan seru bersama Nopup. Kamu bisa isi cash
                                        PB Zepetto kamu dengan beragam metode pembayaran. Cukup masukkan ID kamu, pilih
                                        nominal lalu lakukan pembayaran dan top up PB Zepetto akan langsung masuk ke
                                        akun kamu.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide card-produk">
                            <img src="10.png" alt="">
                            <div class="detail-produk">
                                <div class="kategori">
                                    <a href="game10.php">Top Up</a>
                                </div>
                                <div class="title-card">
                                    <h1>Steam</h1>
                                </div>
                                <div class="body-card">
                                    <p>Top Up Steam Wallet Codes atau Steam Gift Card hanya dalam hitungan detik!<br>
                                        Cukup masukan jumlah saldo Steam Wallet yang Anda inginkan,<br> pilih metode
                                        pembayaran dan selesaikan transaksi Anda.<br> Kemudian Anda akan mendapatkan
                                        kode Steam Wallet pada pesan konfirmasi pembayaran via email.
                                    </p>
                                </div>
                                <div class="btn-produk">
                                    <a href="#">Detail</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container2">
            <ul>
                <li class="menu">
                    <a href="http://localhost/ga/index.php" class="text"><b>Game Mobile</b></a>
                </li>
                <li class="menu">
                    <a href="GamePC.php" class="text"><b>Game PC</b></a>
                </li>
            </ul>
        </div>
        <div class="container3">
            <div class="row3">
                <div class="card-produk2">
                    <img src="1.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game11.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>Mobile Legends Bang-Bang</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up MLBB/Mobile Legends: Bang Bang sekarang semakin mudah bersama NopUp! Kamu bisa
                                menggunakannya untuk memiliki Starlight Member, Twilight Pass, membeli skin favorit
                                kesukaanmu. Cukup masukkan ID, pilih nominal dan lakukan pembayaran.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="2.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="https://www.midasbuy.com/midasbuy/id/homepage/pubgm">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>PUBG Mobile (Indonesia)</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up PUBG Mobile menggunakan voucher kode redeem (redeem code) hanya dalam hitungan
                                detik! Cukup pilih jumlah voucher UC yang Anda inginkan, selesaikan pembayaran, dan kode
                                voucher PUBG Mobile langsung terkirim dalam hitungan detik.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="4.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game12.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>Free Fire</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up diamond Free Fire melalui NopUp. Bagaimana caranya? Kamu tinggal masukkan ID kamu
                                lalu pilih nominal yang diinginkan. NopUp menyediakan pilihan mulai 5 sampai 73.200 Free
                                Fire Diamonds. Kamu bisa menggunakannya untuk membeli karakter, skin hingga mendapatkan
                                item eksklusif untuk mendukung permainanmu.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="5.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game2.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>Genshin Impact</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up Genshin Impact? Beli Genesis Crystals Genshin Impact dengan mudah dan cepat di
                                NopUp! Caranya mudah! Cukup masukan UID dan Server, pilih jumlah Genesis Crystals yang
                                diinginkan, lakukan pembayaran. Bisa bayar melalui DANA, OVO, ShopeePay, GO-PAY,
                                LinkAja, BNI, BCA, CIMB Clicks, Mandiri, Permata, Indomaret, Alfamart, dan lain-lain.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="3.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game14.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>Call of Duty (Mobile)</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up atau beli Call of Duty Mobile Points (CP) termurah dan tercepat! Caranya mudah!
                                Cukup isi ID, pilih nominal yang diinginkan, lakukan pembayaran, lalu CP akan langsung
                                bertambah ke akun Call of duty Mobile kamu! Top up cod mobile bisa bayar melalui GO-PAY,
                                DANA, OVO, BNI, BCA, CIMB Clicks, Mandiri, Permata, Indomaret, Alfamart, Kartu Kredit.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="6.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game1.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>Stumble Guys</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up Gems Stumble Guys hanya dalam hitungan detik! Cukup masukan User ID Stumble Guys
                                Anda, pilih jumlah Gems yang Anda inginkan, selesaikan pembayaran, dan Gems akan secara
                                langsung ditambahkan ke akun Stumble Guys Anda. Bayarlah menggunakan Bank Transfer,
                                Alfamart, Indomaret, GoPay, OVO, Shopee Pay, DANA, dan kartu kredit.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="8.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game15.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>Arena of Valor</h1>
                        </div>
                        <div class="body-card2">
                            <p>Arena of Valor adalah game mobile dengan genre MOBA. Kalian sedang cari cara top up AOV
                                praktis dan cepat? Beli voucher AOV di NopUp jawabannya. Bayarlah menggunakan Indosat,
                                XL, Tri Indonesia, Smartfren, Bank Transfer, Alfamart, DOKU, Indomaret, GoPay, Kredivo,
                                OVO, Shopee Pay, LinkAja, DANA, QRIS, dan kartu kredit. Tanpa perlu registrasi ataupun
                                log-in.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="12.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game13.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>e Football 2023 Mobile</h1>
                        </div>
                        <div class="body-card2">
                            <p>NopUp menyediakan topup eFootball PES 2023 100% legal lengkap Google Invoice. Jika ada
                                pertanyaan, mohon jangan ragu untuk menghubungi layanan pelanggan kami. Topup eFootball
                                PES 2023 di NopUp dijamin 100% legal dan aman karena akan diisi langsung dari ingame!
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="13.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="game16.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1> League of Legends Wild Rift</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up LOL Wild Rift dalam hitungan detik! Cukup masukan Riot ID Anda, pilih jumlah Wild
                                Core yang Anda inginkan, pilih metode pembayaran dan selesaikan transaksi Anda. Wild
                                Core akan otomatis masuk ke akun League of Legends: Wild Rift Anda.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
                <div class="card-produk2">
                    <img src="11.png" alt="">
                    <div class="detail-produk2">
                        <div class="kategori2">
                            <a href="Game3.php">Top Up</a>
                        </div>
                        <div class="title-card2">
                            <h1>Clash of clans</h1>
                        </div>
                        <div class="body-card2">
                            <p>Top up Gems Clash of Clans hanya dalam hitungan detik! Cukup masukan Supercell ID Clash
                                of Clans Anda, pilih jumlah Gems yang Anda inginkan, selesaikan pembayaran, dan Gems
                                akan secara langsung ditambahkan ke akun Clash of Clans Anda. Bayarlah menggunakan Bank
                                Transfer, Alfamart, Indomaret, GoPay, OVO, ShopeePay, DANA, dan kartu kredit.
                            </p>
                        </div>
                        <div class="btn-produk2">
                            <a href="#">Detail</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="footer">
        <div class="rangkaian">
            <div class="baris">
                <figure>
                    <a href="index.php">
                        <img src="logo.png">
                        <p>Top Up Murah & Terpercaya <br> Pakai NopUp</p>
                    </a>
                </figure>
            </div>
            <div class="baris">
                <h2>Halaman</h2>
                <p>
                    <a href="index.php">Halaman Utama</a>
                </p>
                <p>
                    <a href="cek-pesanan.php">Cek Pesanan</a>
                </p>
                <p>
                    <a href="Syarat&ketentuan.php">Syarat&Ketentuan</a>
                </p>
            </div>
            <div class="baris">
                <h2>Sosial Media</h2>
                <div class="social">
                    <a href="#" class="fa fa-instagram"></a>
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-youtube"></a>
                </div>
            </div>
        </div>
        <div class="grup">
            <small>Hak Cipta &copy; 2024 <b>NopUp</b>Seluruh hak cipta</small>
        </div>
    </footer>
    <script>
        let subMenu = document.getElementById("subMenu");

        function tonggleMenu() {
            subMenu.classList.toggle("open-menu");
        }

        var slideIndex = 1;
        showSlide(slideIndex);

        function nextslide(n) {
            showSlide(slideIndex += n);
        }

        function dotslide(n) {
            showSlide(slideIndex = n);
        }

        function showSlide(n) {
            var i;
            var slides = document.getElementsByClassName("imgslide");
            var dot = document.getElementsByClassName("dot");

            if (n > slides.length) {
                slideIndex = 1
            }
            if (n < 1) {
                slideIndex = slides.length;
            }
            for (i = 0; i < slides.length; i++) {

                slides[i].style.display = "none";
            }

            for (i = 0; i < slides.length; i++) {

                dot[i].className = dot[i].className.replace(" active", "");
            }

            slides[slideIndex - 1].style.display = "block";

            dot[slideIndex - 1].className += " active";
        }
    </script>

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script src="main.js"></script>
    <!--Icons-->
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
</body>

</html>