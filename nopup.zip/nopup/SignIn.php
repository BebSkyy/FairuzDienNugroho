<?php 
session_start();
require 'connect.php';
if (isset($_POST["login"])) {
  $username = $_POST['username'];
  $password = $_POST["password"];
  $cekuser = mysqli_query($conn, "SELECT * FROM akun WHERE username = '$username'");

  if (mysqli_num_rows($cekuser) > 0) {
    $hasil = mysqli_fetch_assoc($cekuser);
    var_dump($hasil['password']); 
    var_dump($password); 

    if ($password == $hasil['password']) {
			$_SESSION["user"] = $username;
			$_SESSION["loggedin"] = true;
      header('Location: index.php');
		} else {
      echo "<script>alert('Password tidak sesuai!');</script>";
    }
  }
}
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="p.png" type="image/x-icon">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.rtl.min.css"
    integrity="sha384-T5m5WERuXcjgzF8DAb7tRkByEZQGcpraRTinjpywg37AO96WoYN9+hrhDVoM6CaT" crossorigin="anonymous">
  <link rel="stylesheet" href="style3.css">

  <!--Fonts-->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">


</head>

<body>

  <div class="split left">
    <div class="container">
      <a href="index.php">
        <img src="back2.png">
      </a>
    </div>
    <div class="centered">
      <a href="https://fonts.google.com/">
        <img src="logo.png" style="height: 60px" alt="Avatar 1">
      </a>
      <h5>Top Up Murah &<br>
        Terpercaya<br>
        Pakai NopUp</h5>
    </div>
  </div>

  <div class="split right">

    <form action="" method="POST">
      <div class="row">
        <div class="header">
          <h1>Sign In</h1>

        </div>
        <div class="login-form">
          <label for="text" class="form-label">Username</label>
          <input name="username" type="text" class="form-control" id="text" placeholder="Enter your Username"
            autocomplete="off" required="true" autofocus="on">

          <label for="password" class="form-label">Password</label>
          <input name="password" type="Password" class="form-control" id="password" placeholder="Enter your Password"
            required="true">
          <a href="#" class="text-decoration-none text-center">Forgot password</a>
          <button class="signin" name="login" type="submit">Login</button>
          <button class="signin-google"><img src="icon.png"> Sign in with Google</button>
          <div class="text-center">
            <span class="d-inline">Don’t have an account? <a href="SignUp.php"
                class="text-decoration-none d-inline">Sign Up</a></span>
          </div>
        </div>
      </div>
    </form>
  </div>
  <button onclick="goBack()">Go Back</button>
  <script>
    function goBack() {
      window.history.back();
    }
  </script>
  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: Bootstrap Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
    crossorigin="anonymous"></script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
          <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
          -->
</body>

</html>