let menuOpen = document.querySelector('.menu-toggle');
let menuWrapper = document.querySelector('.menu-wrapper');

menuOpen.addEventListener('click', function () {
    
    menuOpen.classList.toggle('bxs-x-square');
    menuWrapper.classList.toggle('active');
})
    var swiper = new Swiper(".mySwiper", {
      grabCursor: true,
      centeredSlides: false,
      spaceBetween: 40,
      slidesPerView: "auto",
      coverflowEffect: {  
        rotate: 0,
        stretch: 0,
        depth: 0,
        modifier: 1,
        slideShadows: true,
      },
      navigation: {
        nextEl: ".bxs-chevron-right-circle",
        prevEl: ".bxs-chevron-left-circle",
      },
    });
