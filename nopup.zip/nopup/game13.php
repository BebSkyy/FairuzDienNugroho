<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id" class="translated-ltr">
  <head>
    <meta charset"UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>NopUp TopUp murah terpercaya</title>

    <link rel="icon" href="logo2.png" type="image/x-icon" />
    <meta name="description" content="Top Up Murah & Terpercaya Pakai NopUp" />
    <meta name="keywords" content="NopUp TopUp" />
    <link rel="stylesheet" href="game13.css" />
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />
    <!-- Link Swiper's CSS -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"
    />
  </head>

  <body>
    <header>
      <nav class="navbar">
        <div class="container nav-wrapper">
          <a href="index.php" class="logo">
            <img src="logo.png" alt="" />
          </a>
          <div class="menu-wrapper">
            <ul class="menu">
              <li class="menu-item">
                <a href="index.php" class="menu-link active">Home</a>
              </li>
              <li class="menu-item">
                <a href="cek-pesanan.php" class="menu-link">Cek Pesanan</a>
              </li>
              <li class="menu-item">
                <a href="Syarat&ketentuan.php" class="menu-link"
                  >Syarat & ketentuan</a
                >
              </li>
            </ul>
            <?php
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
                ?>
                <img src="user.png" class="user-pic" onclick="tonggleMenu()">
                <div class="sub-menu-wrap" id="subMenu">
                    <div class="sub-menu">
                        <div class="user-info">
                            <img src="user.png" />
                            <h3><?php
                            echo $_SESSION['user'];
                            ?></h3>
                        </div>
                        <hr>
                        <a href="logout.php" class="sub-menu-link">
                            <img src="logout.png">
                            <p>Logout</p>
                            <span>></span>
                        </a>
                    </div>
                </div>
                <?php
            } else {
                ?>
                <a href="SignIn.php" class="btn-member">Login</a>
            </div>
            <?php
            }
            ?>
          </div>
          <div class="menu-toggle bx bxs-grid-alt"></div>
        </div>
      </nav>
    </header>

    <div class="contract">
      <div class="content">
        <div class="profile-game">
          <img src="pes.png" alt="" />
          <div class="text-box">
            <h2>e Football Mobile</h2>
            <h6>Konami</h6>
          </div>
          <p class="line">
            NopUp menyediakan topup eFootball PES 2023 100% legal lengkap Google Invoice. Jika ada pertanyaan, mohon jangan ragu untuk menghubungi layanan pelanggan kami. <br><br>
            Topup eFootball PES 2023 di NopUp dijamin 100% legal dan aman karena akan diisi langsung dari ingame! <br><br>
            Top up myClub Coin eFootball PES 2023 hanya dalam hitungan menit! Cukup isi form order sesuai data akunmu, pilih jumlah myClub Coin yang Anda inginkan, selesaikan pembayaran, dan admin NopUp akan segera membantu anda untuk topup. <br><br>
            Unduh & Mainkan eFootball PES 2023 sekarang!
          </p>
        </div>
      </div>

      <div class="logreg-box">
        <div class="pay-step">
          <div class="number">
            <p>1</p>
          </div>
          <p class="side-line">Masukkan ID Konami</p>
          <div class="id-input">
            <input type="text" placeholder="ID Konami" />
          </div>
        </div>

        <div class="pay-step pay-step-two">
          <div class="number">
            <p>2</p>
          </div>
          <p class="side-line">Pilih Jumlah</p>
          <div class="id-button">
            <button>300 MYCLUB Coins</button>
            <button>520 MYCLUB Coins</button>
            <button>1,050 MYCLUB Coins</button>
            <button>2,150 MYCLUB Coins</button>
          </div>
          <div class="id-button">
            <button>3,250 MYCLUB Coins</button>
            <button>5,070 MYCLUB Coins</button>
          </div>
        </div>

        <div class="pay-step pay-step-three">
          <div class="number">
            <p>3</p>
          </div>
          <p class="side-line-method">Pilih Metode Pembayaran</p>
          <div class="id-method">
            <button>
              <img
                src="logo bank.png"
                class="logo-bank"
              />
            </button>
            <button>
              <img src="878272_720.jpg" class="ovo" />
            </button>
            <button>
              <img
                src="DANA__1_Logo.jpg"
                class="dana"
              />
            </button>
            <button>
              <img src="gopay.png" class="gopay" />
            </button>
            <button>
              <img
                src="shoopeepay.jpeg"
                class="shopee"
              />
            </button>
            <button>
              <img
                src="indomaret.jpeg"
                class="indomaret"
              />
            </button>
            <button>
              <img
                src="alfamart.png"
                class="alfamart"
              />
            </button>
          </div>
        </div>
        <div class="pay-step pay-step-four">
          <div class="number">
            <p>4</p>
          </div>
          <p class="side-line-four">Alamat Email (Opsional)</p>
          <div class="id-input">
            <input type="text" placeholder="Email" />
          </div>
          <p class="side-line-bottom">
            Jika anda ingin mendapatkan bukti pembayaran atas pembelianm anda,
            harap mengisi alamat emailnya
          </p>
        </div>
      </div>
    </div>

    <div class="footer">
      <div class="rangkaian">
        <div class="baris">
          <figure>
            <a href="index.php">
              <img src="logo.png" />
              <p>
                Top Up Murah & Terpercaya <br />
                Pakai NopUp
              </p>
            </a>
          </figure>
        </div>
        <div class="baris">
          <h2>Halaman</h2>
          <p>
            <a href="index.php">Halaman Utama</a>
          </p>
          <p>
            <a href="cek-pesanan.php">Cek Pesanan</a>
          </p>
          <p>
            <a href="Syarat&ketentuan.php">Syarat&Ketentuan</a>
          </p>
        </div>
        <div class="baris">
          <h2>Sosial Media</h2>
          <div class="social">
            <a href="#" class="fa fa-instagram"></a>
            <a href="#" class="fa fa-facebook"></a>
            <a href="#" class="fa fa-twitter"></a>
            <a href="#" class="fa fa-youtube"></a>
          </div>
        </div>
      </div>
      <div class="grup">
        <small>Hak Cipta &copy; 2024 <b>NopUp</b>Seluruh hak cipta</small>
      </div>
    </div>
    <script>
        let subMenu = document.getElementById("subMenu");
        function tonggleMenu() {
        subMenu.classList.toggle("open-menu");
        }
    </script>
    <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
  </body>
</html>
