<?php
  session_start();
  session_unset();
  session_destroy();
  $_SESSION['username']=null; 
  $_SESSION['loggedin']=null; 
  header("Location: index.php");
  
?>